package livrokotlin.com.farmaciaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_categoria_infantil.*
import kotlinx.android.synthetic.main.activity_categoria_saude.*
import kotlinx.android.synthetic.main.content_home.*
import livrokotlin.com.farmaciaapp.Conta.CestaComprasActivity
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast

class CategoriaInfantilActivity : AppCompatActivity() {

    override fun onResume() {
        super.onResume()

        if( searchIntProduto != null ){

            listItem_categoria_infantil.setSelection(searchIntProduto!!.toInt())
            searchIntProduto = null

        }

        val adapter = listItem_categoria_infantil.adapter as ProdutoAdapter

        adapter.clear()
        adapter.addAll(produtosGlobalInfantil)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categoria_infantil)


        val adapter = ProdutoAdapter(this)
        listItem_categoria_infantil.adapter = adapter

        val arrayAdapter = ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, nomesProdutosInfantilGlobal)
        et_buscador_globalInfantil.setAdapter(arrayAdapter)

        btn_searchInfantil.setOnClickListener {
            listItem_categoria_infantil.setSelection(buscarItem())
        }

        btn_comprasInfantil.setOnClickListener {

            startActivity<CestaComprasActivity>()

        }

        btn_voltarInfantil.setOnClickListener {

            finishFromChild(this)

        }

        listItem_categoria_infantil.setOnItemClickListener { _, _, position, _ ->

            detalhesProduto = adapter.getItem(position)

            startActivity<DetalhesProdutosActivity>()

        }

    }

    private fun buscarItem(): Int{

        val item= et_buscador_globalInfantil.text.toString()
        et_buscador_globalInfantil.text.clear()
        val posicao: Int

        posicao = nomesProdutosInfantilGlobal.indexOf(item)

        return posicao

    }
}
