package livrokotlin.com.farmaciaapp.Conta

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_endereco_usuario.*
import livrokotlin.com.farmaciaapp.*
import livrokotlin.com.farmaciaapp.R

class EnderecoUsuarioActivity : AppCompatActivity() {


    val TAG = "MainActivity"

    private lateinit var mDatabaseReference: DatabaseReference
    private lateinit var mDatabase: FirebaseDatabase

    override fun onResume() {
        super.onResume()
        endereco()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_endereco_usuario)

        btn_alterar_endereco.setOnClickListener {

            mDatabase = FirebaseDatabase.getInstance()
            mDatabaseReference = mDatabase.reference.child("Contas").child("Clientes").child(cpfDataBase.toString()).child("endereco")

            mDatabaseReference.setValue(txt_novo_endereco.text.toString())

        }

    }

    private fun endereco(){

        mDatabase = FirebaseDatabase.getInstance()
        mDatabaseReference = mDatabase.reference.child("Contas").child("Clientes").child(cpfDataBase.toString()).child("endereco")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val value = dataSnapshot.getValue(String::class.java)
                if(value != null){
                    meu_endereco.text = value.toString()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())
            }
        })
    }

}
