@file:Suppress("DEPRECATION")

package livrokotlin.com.farmaciaapp

import android.app.ProgressDialog
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_cadastro.*
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.toast

class CadastroActivity : AppCompatActivity() {

    private lateinit var mDatabaseReference: DatabaseReference
    private lateinit var mDatabase: FirebaseDatabase
    private lateinit var mAuth: FirebaseAuth
    val TAG = "CreateAccountActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        txt_cpfCadastro.text = cpfGlobal

        init()

    }

    private fun init(){

        val prgDialog = ProgressDialog(this@CadastroActivity)

        mDatabase = FirebaseDatabase.getInstance()
        mDatabaseReference = mDatabase.reference.child("Contas").child("Clientes")
        mAuth = FirebaseAuth.getInstance()

        btn_cadastrar.setOnClickListener {

            val usuario = User(
                password = txt_senhaCadastro.text.toString(),
                email = txt_emailCadastro.text.toString(),
                cpf = txt_cpfCadastro.text.toString(),
                telefone = txt_telefoneCadastro.text.toString(),
                endereco = txt_enderecoCadastro.text.toString(),
                nome = txt_nomeCadastro.text.toString()
            )

            if(txt_senhaCadastro.text.isNotEmpty() && txt_cpfCadastro.text.isNotEmpty() && txt_emailCadastro.text.isNotEmpty() && txt_enderecoCadastro.text.isNotEmpty() && txt_telefoneCadastro.text.isNotEmpty() && txt_nomeCadastro.text.isNotEmpty()){

                prgDialog.setMessage("Criando nova conta...")
                prgDialog.show()

                mAuth.createUserWithEmailAndPassword(usuario.email.toString(), usuario.password.toString()).addOnCompleteListener(this){
                    task ->

                    prgDialog.hide()

                    if(task.isSuccessful){

                        Log.d(TAG, "CreateUserWithEmail:Sucess")
                        //val userId = mAuth.currentUser!!.uid // MUDAR CPF

                        verificarEmail()

                        val currentUserDb = mDatabaseReference.child(usuario.cpf.toString())
                        currentUserDb.setValue(usuario)

                        finishFromChild(this)

                        //updateUserInfoAndUi()

                    }else{

                        Log.w(TAG, "CreateUserWithEmail:Faillure", task.exception)
                        toast("A Autenticação falhou")

                    }

                }
            }else {
                if (txt_senhaCadastro.text.isEmpty())
                    txt_senhaCadastro.error = "Insira um valor"
            }


        }
    }

    private fun updateUserInfoAndUi(){

        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)

    }

    private fun verificarEmail(){

        val mUser = mAuth.currentUser
        mUser!!.sendEmailVerification().addOnCompleteListener(this){
            task ->

            if(task.isSuccessful){

                toast("Email verificado ${mUser.email}")

            }else{

                Log.e(TAG, "SendEmailVerification", task.exception)
                toast("Email não verificado")

            }

        }

    }

}
