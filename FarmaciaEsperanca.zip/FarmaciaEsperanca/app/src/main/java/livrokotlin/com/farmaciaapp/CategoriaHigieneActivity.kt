package livrokotlin.com.farmaciaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_categoria_beleza.*
import kotlinx.android.synthetic.main.activity_categoria_higiene.*
import kotlinx.android.synthetic.main.activity_categoria_saude.*
import kotlinx.android.synthetic.main.content_home.*
import livrokotlin.com.farmaciaapp.Conta.CestaComprasActivity
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast

class CategoriaHigieneActivity : AppCompatActivity() {

    override fun onResume() {
        super.onResume()

        if( searchIntProduto != null ){

            listItem_categoria_higiene.setSelection(searchIntProduto!!.toInt())
            searchIntProduto = null

        }

        val adapter = listItem_categoria_higiene.adapter as ProdutoAdapter

        adapter.clear()
        adapter.addAll(produtosGlobalHigiene)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categoria_higiene)


        val adapter = ProdutoAdapter(this)
        listItem_categoria_higiene.adapter = adapter

        val arrayAdapter = ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, nomesProdutosHigieneGlobal)
        et_buscador_globalHigiene.setAdapter(arrayAdapter)

        btn_searchHigiene.setOnClickListener {
            listItem_categoria_higiene.setSelection(buscarItem())
        }

        btn_comprasHigiene.setOnClickListener {

            startActivity<CestaComprasActivity>()

        }

        btn_voltarHigiene.setOnClickListener {

            finishFromChild(this)

        }

        listItem_categoria_higiene.setOnItemClickListener { _, _, position, _ ->

            detalhesProduto = adapter.getItem(position)

            startActivity<DetalhesProdutosActivity>()

        }

    }

    private fun buscarItem(): Int{

        val item= et_buscador_globalHigiene.text.toString()
        et_buscador_globalHigiene.text.clear()
        val posicao: Int

        posicao = nomesProdutosHigieneGlobal.indexOf(item)

        return posicao

    }
}
