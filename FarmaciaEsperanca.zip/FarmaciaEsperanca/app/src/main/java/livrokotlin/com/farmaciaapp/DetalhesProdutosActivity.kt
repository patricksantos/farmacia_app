package livrokotlin.com.farmaciaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import kotlinx.android.synthetic.main.activity_detalhes_produtos.*
import kotlinx.android.synthetic.main.activity_detalhes_produtos.btn_mais
import kotlinx.android.synthetic.main.activity_detalhes_produtos.btn_menos
import kotlinx.android.synthetic.main.activity_detalhes_produtos.view.*
import kotlinx.android.synthetic.main.item_cesta_compras.*
import livrokotlin.com.farmaciaapp.Conta.CestaComprasActivity
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast

class DetalhesProdutosActivity : AppCompatActivity() {

    override fun onResume() {
        super.onResume()

        val produto = detalhesProduto!!
        txt_nomeProdutoDetalhes.text = produto.nome.toString()
        txt_preçoProdutoDetalhes.text = produto.valor.toString()
        txt_qtdProdutoDetalhes.text = produto.qtd.toString()
    }

    override fun onDestroy() {
        super.onDestroy()
        detalhesProduto = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalhes_produtos)

        var qtd = 0
        edt_quantidade_produto_detalhesProdutos.text = qtd.toString()

        btn_mais.setOnClickListener {
            if( qtd < txt_qtdProdutoDetalhes.text.toString().toInt() ){
                qtd++
                edt_quantidade_produto_detalhesProdutos.text = qtd.toString()
            }else if( qtd == txt_qtdProdutoDetalhes.text.toString().toInt() ){
                btn_menos.isActivated = false
            }
        }

        btn_menos.setOnClickListener {
            if( qtd > 0 ){
                qtd--
                edt_quantidade_produto_detalhesProdutos.text = qtd.toString()
            }else if( qtd == 0 ){
                btn_menos.isActivated = false
            }
        }

        btn_addProdutoCesta.setOnClickListener {

            if( edt_quantidade_produto_detalhesProdutos.text.toString().toInt() > 0){

                val produto = detalhesProduto!!.copy()

                produto.qtd = edt_quantidade_produto_detalhesProdutos.text.toString().toInt()

                if( !produtosMinhaCesta.contains(produto) ){
                    produtosMinhaCesta.add(produto)
                    toast("Produto adicionado à cesta")
                }else{
                    toast("Produto já adicionado à cesta")
                }

            }else{
                toast("Insira a quantidade")
            }
        }

        btn_compras2.setOnClickListener {
            startActivity<CestaComprasActivity>()
        }

        btn_voltar.setOnClickListener {
            finishFromChild(this@DetalhesProdutosActivity)
        }


    }

}
