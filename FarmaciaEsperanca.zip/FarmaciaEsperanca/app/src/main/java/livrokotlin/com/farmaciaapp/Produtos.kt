package livrokotlin.com.farmaciaapp

import android.graphics.Bitmap
import android.text.Editable
import android.util.Log
import android.widget.Button
import com.google.firebase.database.*

data class Produto(
    var nome:String? = null,
    var categoria: String? = null,
    var valor: Double? = null,
    var foto: Bitmap? = null,
    var qtd: Int? = null,
    var btn: Button? = null
)




