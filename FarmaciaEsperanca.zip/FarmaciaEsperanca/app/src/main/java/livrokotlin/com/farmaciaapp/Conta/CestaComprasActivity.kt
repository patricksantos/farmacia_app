package livrokotlin.com.farmaciaapp.Conta

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import kotlinx.android.synthetic.main.activity_categoria_saude.*
import kotlinx.android.synthetic.main.activity_cesta_compras.*
import kotlinx.android.synthetic.main.content_cesta_produtos.*
import kotlinx.android.synthetic.main.item_cesta_compras.*
import kotlinx.android.synthetic.main.item_cesta_compras.view.*
import livrokotlin.com.farmaciaapp.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.noButton
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.yesButton

class CestaComprasActivity : AppCompatActivity() {

    override fun onResume() {
        super.onResume()

        if( produtosMinhaCesta.isEmpty() ){

            alert("Nenhum produto adicionado\nAcesse nossas categorias e veja nossos produtos.", "Cesta vazia"){
                yesButton {
                    startActivity<CategoriasActivity>()
                }
                noButton {
                    finishFromChild(this@CestaComprasActivity)
                }
            }.show()
        }

        adapterCestaGlobal = list_item_cesta.adapter as ProdutoCestaAdapter

        adapterCestaGlobal!!.clear()
        adapterCestaGlobal!!.addAll(produtosMinhaCesta)

        somaTotalProdutosGlobal = produtosMinhaCesta.sumByDouble { it.valor!! * it.qtd!!.toInt() }
        txt_precoProduto_total.text = somaTotalProdutosGlobal.toString()

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cesta_compras)

        adapterCestaGlobal = ProdutoCestaAdapter(this)
        list_item_cesta.adapter = adapterCestaGlobal

    }
}
/*alert("Você deseja remover este item?.", "Remover item"){
    yesButton {

        val produto = adapter.getItem(position)
        produtosMinhaCesta.remove(produto!!)
        adapter.remove(produto)

    }
    noButton {}
}.show()*/