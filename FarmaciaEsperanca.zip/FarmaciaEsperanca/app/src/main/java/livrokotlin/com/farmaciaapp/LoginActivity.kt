@file:Suppress("DEPRECATION")

package livrokotlin.com.farmaciaapp

import android.app.ProgressDialog
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_login.*
import org.jetbrains.anko.db.insert
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast

class LoginActivity : AppCompatActivity() {

    val TAG = "LoginActivity"
    private lateinit var mDatabaseReference: DatabaseReference
    private lateinit var mDatabase: FirebaseDatabase
    //private var mProgressBar: ProgressDialog? = null

    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        txt_cpfLogin.text = cpfGlobal

        init()

    }


    private fun init(){

        mAuth = FirebaseAuth.getInstance()

        criarConta.setOnClickListener {
            startActivity<CadastroActivity>()
        }

        esqueciSenha.setOnClickListener {
            startActivity<EsqSenhaActivity>()
        }

        btn_entrar.setOnClickListener {
            loginUser()
        }

    }

    private fun loginUser(){

        val cpf = txt_cpfLogin?.text.toString()

        val prgDialog = ProgressDialog(this@LoginActivity)

        //val emailLogin = txt_cpfLogin?.text.toString()
        val senhaLogin = txt_senhaLogin?.text.toString()

        mDatabase = FirebaseDatabase.getInstance()
        mDatabaseReference = mDatabase.reference.child("Contas").child("Clientes").child(cpf).child("email")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                val value = dataSnapshot.getValue(String::class.java)
                Log.d(TAG, "Value is: $value")

                prgDialog.setMessage("Verificando Usuario")
                prgDialog.show()

                Log.d(TAG, "Login do usuario")

                if( txt_cpfLogin.text.isNotEmpty() && txt_senhaLogin.text.isNotEmpty()){

                    prgDialog.setMessage("Verificando Usuario")
                    prgDialog.show()

                    Log.d(TAG, "Login do usuario")

                    mAuth.signInWithEmailAndPassword(value.toString(), senhaLogin).addOnCompleteListener(this@LoginActivity){
                            task ->
                        prgDialog.hide()

                        //Autenticando o usuario, atualizando o Ui com as informações de login
                        if (task.isSuccessful){
                            saveData(cpf, senhaLogin)
                            Log.d(TAG, "Logado com sucesso")
                            updateUi()
                        }else{
                            Log.e(TAG, "Erro ao logar", task.exception)
                            toast("Autenticação falhou.")
                        }
                    }
                }else{
                    toast("Entre com mais detalhes.")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

                startActivity<CadastroActivity>()

            }
        })


    }

    private fun updateUi(){

        txt_cpfLogin.text.clear()
        txt_senhaLogin.text.clear()

        startActivity<HomeActivity>()

    }

    private fun saveData(cpfLogin: String, senhaLogin: String){

        database.use {

            insert(
                "DadosLogin",
                "cpf" to cpfLogin,
                "senha" to senhaLogin
            )

        }

        cpfDataBase = cpfLogin

    }

}
