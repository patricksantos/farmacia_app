package livrokotlin.com.farmaciaapp

import android.os.Bundle
import android.support.design.widget.BottomSheetBehavior
import android.support.v4.view.GravityCompat
import android.support.v7.app.ActionBarDrawerToggle
import android.view.MenuItem
import android.support.v4.widget.DrawerLayout
import android.support.design.widget.NavigationView
import android.support.v4.view.ViewPager
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.app_bar_home.*
import kotlinx.android.synthetic.main.aqui.*
import kotlinx.android.synthetic.main.content_home.*
import kotlinx.android.synthetic.main.nav_header_home.*
import livrokotlin.com.farmaciaapp.Conta.CestaComprasActivity
import org.jetbrains.anko.db.delete
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast

class HomeActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    val TAG = "HomeActivity"
    private lateinit var mDatabase: FirebaseDatabase
    private lateinit var mDatabaseReference: DatabaseReference

    override fun onResume() {
        super.onResume()

        dataUser()

        produtosGlobal.addAll(produtosGlobalSaude)
        produtosGlobal.addAll(produtosGlobalBeleza)
        produtosGlobal.addAll(produtosGlobalHigiene)
        produtosGlobal.addAll(produtosGlobalInfantil)

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val bottomSheet = findViewById<View>(R.id.btn_botton_sheet)

        val mBottomSheetBehavior = BottomSheetBehavior.from(bottomSheet)
        mBottomSheetBehavior.setBottomSheetCallback( object : BottomSheetBehavior.BottomSheetCallback(){
            override fun onSlide(p0: View, p1: Float) {
            }

            override fun onStateChanged(p0: View, p1: Int) {

                if(mBottomSheetBehavior.state == BottomSheetBehavior.STATE_EXPANDED){

                    btn_imagemPromo.rotation = 180f

                }else if(mBottomSheetBehavior.state == BottomSheetBehavior.STATE_COLLAPSED){

                    btn_imagemPromo.rotation = 0f

                }

            }
        })

        btn_botton_sheet_upDown.setOnClickListener {

            if(mBottomSheetBehavior.state == BottomSheetBehavior.STATE_COLLAPSED){

                mBottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
                btn_imagemPromo.rotation = 180f

            }else{

                mBottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
                btn_imagemPromo.rotation = 0f

            }

        }

        val arrayAdapter = ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, nomesProdutosGlobal)
        et_buscador_global.setAdapter(arrayAdapter)

        init()

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )

        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)
    }

    override fun onBackPressed() {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        when (item.itemId) {
            R.id.nav_home -> {
                startActivity<HomeActivity>()
            }
            R.id.nav_minha_conta -> {
                startActivity<MinhaContaActivity>()
            }
            R.id.nav_meus_pedidos -> {
                startActivity<CestaComprasActivity>()
            }
            R.id.nav_logout -> {
                database.use {
                    delete("DadosLogin")
                }
                startActivity<MainActivity>()
            }
        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)

        return true

    }

    private fun init(){

        image_slide1.setOnClickListener {
            startActivity<CategoriasActivity>()
        }

        image_slide2.setOnClickListener {
            startActivity<CategoriasActivity>()
        }

        image_slide3.setOnClickListener {
            startActivity<CategoriasActivity>()
        }

        image_slide4.setOnClickListener {
            startActivity<CategoriasActivity>()
        }

        btn_categoria_saude.setOnClickListener {
            startActivity<CategoriaSaudeActivity>()
        }

        btn_categoria_infantil.setOnClickListener {
            startActivity<CategoriaInfantilActivity>()
        }

        btn_categoria_higiene.setOnClickListener {
            startActivity<CategoriaHigieneActivity>()
        }

        btn_categoria_beleza.setOnClickListener {
            startActivity<CategoriaBelezaActivity>()
        }

        btn_verMais.setOnClickListener {
            startActivity<CategoriasActivity>()
        }

        btn_compras.setOnClickListener {
            startActivity<CestaComprasActivity>()
        }

        btn_searchGlobal.setOnClickListener {
            searchIntProduto = buscarProduto()
            if( searchIntProduto == null){
                toast("Produto não encontrado")
            }
        }

        nossa_localizacao.setOnClickListener {
            startActivity<MapsActivity>()
        }
    }

    private fun dataUser(){

        mDatabase = FirebaseDatabase.getInstance()
        mDatabaseReference = mDatabase.reference.child("Contas").child("Clientes").child(cpfDataBase.toString()).child("nome")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                val value = dataSnapshot.getValue(String::class.java)
                name_drawer.text = value.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })

        mDatabaseReference = mDatabase.reference.child("Contas").child("Clientes").child(cpfDataBase.toString()).child("email")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                val value = dataSnapshot.getValue(String::class.java)
                email_drawer.text = value.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })

    }

    private fun buscarProduto(): Int?{

        val item= et_buscador_global.text.toString()
        et_buscador_global.text.clear()

        if( nomesProdutosSaudeGlobal.contains(item) ){

            startActivity<CategoriaSaudeActivity>()
            return nomesProdutosSaudeGlobal.indexOf(item)

        }else if( nomesProdutosInfantilGlobal.contains(item) ){

            startActivity<CategoriaInfantilActivity>()
            return nomesProdutosInfantilGlobal.indexOf(item)

        }else if( nomesProdutosBelezaGlobal.contains(item) ){

            startActivity<CategoriaBelezaActivity>()
            return nomesProdutosBelezaGlobal.indexOf(item)

        }else if( nomesProdutosHigieneGlobal.contains(item) ){

            startActivity<CategoriaHigieneActivity>()
            return nomesProdutosHigieneGlobal.indexOf(item)

        }

        return null

    }

}
