package livrokotlin.com.farmaciaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import com.google.firebase.database.*
import org.jetbrains.anko.db.parseOpt
import org.jetbrains.anko.db.rowParser
import org.jetbrains.anko.db.select
import org.jetbrains.anko.startActivity

class SplashActivity : AppCompatActivity() {

    val TAG = "MainActivity"
    var ver: Boolean? = null

    private lateinit var mDatabaseReference: DatabaseReference
    private lateinit var mDatabase: FirebaseDatabase

    override fun onResume() {
        super.onResume()

        produtosSaude()
        produtosInfantil()
        produtosHigiene()
        produtosBeleza()

        database.use {
            select("DadosLogin").exec{

                val parser = rowParser{
                        cpf: String,
                        senha: String->

                    DadosLogin(cpf, senha)
                }

                val dataLogin = parseOpt(parser)

                cpfDataBase = dataLogin?.cpf
                senhaDataBase = dataLogin?.senha

                ver = cpfDataBase != null && senhaDataBase != null

            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler().postDelayed( Runnable {

            if( ver == true ){
                startActivity<HomeActivity>()
                finishFromChild(this)
            }else{
                startActivity<MainActivity>()
                finishFromChild(this)
            }

        }, 3000)


    }

    private fun produtosSaude(){

        mDatabase = FirebaseDatabase.getInstance()

        mDatabaseReference = mDatabase.reference.child("Produtos").child("categorias").child("saude")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (snapshot: DataSnapshot in dataSnapshot.children) {
                    val value = snapshot.getValue(Produto::class.java)
                    produtosGlobalSaude.add(value!!)
                    nomesProdutosGlobal.add(value.nome.toString())
                    nomesProdutosSaudeGlobal.add(value.nome.toString())
                }


            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })
    }

    private fun produtosBeleza(){

        mDatabase = FirebaseDatabase.getInstance()

        mDatabaseReference = mDatabase.reference.child("Produtos").child("categorias").child("beleza")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (snapshot: DataSnapshot in dataSnapshot.children) {
                    val value = snapshot.getValue(Produto::class.java)
                    produtosGlobalBeleza.add(value!!)
                    nomesProdutosGlobal.add(value.nome.toString())
                    nomesProdutosBelezaGlobal.add(value.nome.toString())
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })
    }

    private fun produtosInfantil(){

        mDatabase = FirebaseDatabase.getInstance()

        mDatabaseReference = mDatabase.reference.child("Produtos").child("categorias").child("infantil")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (snapshot: DataSnapshot in dataSnapshot.children) {
                    val value = snapshot.getValue(Produto::class.java)
                    produtosGlobalInfantil.add(value!!)
                    nomesProdutosGlobal.add(value.nome.toString())
                    nomesProdutosInfantilGlobal.add(value.nome.toString())
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })
    }

    private fun produtosHigiene(){

        mDatabase = FirebaseDatabase.getInstance()

        mDatabaseReference = mDatabase.reference.child("Produtos").child("categorias").child("higiene")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (snapshot: DataSnapshot in dataSnapshot.children) {
                    val value = snapshot.getValue(Produto::class.java)
                    produtosGlobalHigiene.add(value!!)
                    nomesProdutosGlobal.add(value.nome.toString())
                    nomesProdutosHigieneGlobal.add(value.nome.toString())
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })
    }

}
