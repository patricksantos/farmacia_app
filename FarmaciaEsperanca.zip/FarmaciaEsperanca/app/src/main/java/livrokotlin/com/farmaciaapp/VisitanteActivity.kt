package livrokotlin.com.farmaciaapp

import android.os.Bundle
import android.support.v4.view.GravityCompat
import android.support.v7.app.ActionBarDrawerToggle
import android.view.MenuItem
import android.support.v4.widget.DrawerLayout
import android.support.design.widget.NavigationView
import android.support.v4.content.ContextCompat.startActivity
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import kotlinx.android.synthetic.main.activity_visitante.*
import kotlinx.android.synthetic.main.app_bar_home.*
import kotlinx.android.synthetic.main.content_home.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.noButton
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.yesButton

class VisitanteActivity: AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visitante)

        init()
    }

    private fun init(){

        btn_categoria_saude2.setOnClickListener {
            startActivity<CategoriaSaudeActivity>()
        }

        btn_categoria_infantil2.setOnClickListener {
            startActivity<CategoriaInfantilActivity>()
        }

        btn_categoria_higiene2.setOnClickListener {
            startActivity<CategoriaHigieneActivity>()
        }

        btn_categoria_beleza2.setOnClickListener {
            startActivity<CategoriaBelezaActivity>()
        }

        btn_verMais2.setOnClickListener {
            startActivity<CategoriasActivity>()
        }

    }

    private fun msgCadastrar(){

        alert("Para acessar esse conteúdo você deverá estar conectado em uma conta.", "Fazer Loggin ou Cadastro"){
            yesButton {
                finishFromChild(this@VisitanteActivity)
                startActivity<LoginActivity>()
            }
            noButton {}
        }.show()

    }

}
