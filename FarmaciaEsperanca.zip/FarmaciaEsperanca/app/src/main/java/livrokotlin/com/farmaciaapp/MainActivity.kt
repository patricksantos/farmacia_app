@file:Suppress("DEPRECATION")

package livrokotlin.com.farmaciaapp

import android.app.ProgressDialog
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.db.*
import org.jetbrains.anko.startActivity

@Suppress("NAME_SHADOWING")
class MainActivity : AppCompatActivity() {

    val TAG = "MainActivity"

    private lateinit var mDatabaseReference: DatabaseReference
    private lateinit var mDatabase: FirebaseDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        init()

    }

    private fun init(){

        btn_proximo.setOnClickListener {

            cpfDatabase()

        }

        btn_entrarVisitante.setOnClickListener {

            startActivity<VisitanteActivity>()

        }

    }

    private fun cpfDatabase(){

        val prgDialog = ProgressDialog(this@MainActivity)
        val cpf = txt_cpfTelaInicial.text.toString()

        mDatabase = FirebaseDatabase.getInstance()
        mDatabaseReference = mDatabase.reference.child("Contas").child("Clientes").child(cpf).child("cpf")

        prgDialog.setMessage("Verificando CPF")
        prgDialog.show()

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                prgDialog.setMessage("Verificando CPF")
                prgDialog.show()

                val value = dataSnapshot.getValue(String::class.java)
                Log.d(TAG, "Value is: $value")

                if( cpf == value.toString() ){
                    cpfGlobal = txt_cpfTelaInicial.text
                    prgDialog.hide()
                    startActivity<LoginActivity>()

                }else{

                    startActivity<CadastroActivity>()

                }

            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

                startActivity<CadastroActivity>()

            }
        })

    }

    private fun emailDatabase(){

        val email = txt_cpfTelaInicial.text.toString()

        mDatabase = FirebaseDatabase.getInstance()
        mDatabaseReference = mDatabase.reference.child("Contas").child("Clientes").child(email).child("email")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                val value = dataSnapshot.getValue(String::class.java)
                Log.d(TAG, "Value is: $value")

                if( email == value.toString() ){

                    startActivity<LoginActivity>()

                }else{

                    startActivity<CadastroActivity>()

                }

            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

                startActivity<CadastroActivity>()

            }
        })

    }

    private fun addProdutosListas(){

        val prgDialog = ProgressDialog(this@MainActivity)

        prgDialog.setMessage("Buscando Produtos...")
        prgDialog.show()

        mDatabase = FirebaseDatabase.getInstance()
        mDatabaseReference = mDatabase.reference.child("Produtos").child("total").child("produtos")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                val value = dataSnapshot.getValue(Int::class.java)
                Log.d(TAG, "Value is: $value")



                prgDialog.hide()

            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })

    }

    private fun produtosSaude(){

        mDatabase = FirebaseDatabase.getInstance()

        mDatabaseReference = mDatabase.reference.child("Produtos").child("categorias").child("saude")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (snapshot: DataSnapshot in dataSnapshot.children) {
                    val value = snapshot.getValue(Produto::class.java)
                    produtosGlobalSaude.add(value!!)
                    nomesProdutosGlobal.add(value.nome.toString())
                    nomesProdutosSaudeGlobal.add(value.nome.toString())
                }


            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })
    }

    private fun produtosBeleza(){

        mDatabase = FirebaseDatabase.getInstance()

        mDatabaseReference = mDatabase.reference.child("Produtos").child("categorias").child("beleza")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (snapshot: DataSnapshot in dataSnapshot.children) {
                    val value = snapshot.getValue(Produto::class.java)
                    produtosGlobalBeleza.add(value!!)
                    nomesProdutosGlobal.add(value.nome.toString())
                    nomesProdutosBelezaGlobal.add(value.nome.toString())
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })
    }

    private fun produtosInfantil(){

        mDatabase = FirebaseDatabase.getInstance()

        mDatabaseReference = mDatabase.reference.child("Produtos").child("categorias").child("infantil")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (snapshot: DataSnapshot in dataSnapshot.children) {
                    val value = snapshot.getValue(Produto::class.java)
                    produtosGlobalInfantil.add(value!!)
                    nomesProdutosGlobal.add(value.nome.toString())
                    nomesProdutosInfantilGlobal.add(value.nome.toString())
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })
    }

    private fun produtosHigiene(){

        mDatabase = FirebaseDatabase.getInstance()

        mDatabaseReference = mDatabase.reference.child("Produtos").child("categorias").child("higiene")

        // Read from the database
        mDatabaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                for (snapshot: DataSnapshot in dataSnapshot.children) {
                    val value = snapshot.getValue(Produto::class.java)
                    produtosGlobalHigiene.add(value!!)
                    nomesProdutosGlobal.add(value.nome.toString())
                    nomesProdutosHigieneGlobal.add(value.nome.toString())
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())

            }
        })
    }

}