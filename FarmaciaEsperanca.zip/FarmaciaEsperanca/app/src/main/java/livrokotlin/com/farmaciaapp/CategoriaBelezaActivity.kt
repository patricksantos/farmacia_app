package livrokotlin.com.farmaciaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_categoria_beleza.*
import kotlinx.android.synthetic.main.activity_categoria_saude.*
import kotlinx.android.synthetic.main.content_home.*
import livrokotlin.com.farmaciaapp.Conta.CestaComprasActivity
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast

class CategoriaBelezaActivity : AppCompatActivity() {

    override fun onResume() {
        super.onResume()

        if( searchIntProduto != null ){

            listItem_categoria_beleza.setSelection(searchIntProduto!!.toInt())
            searchIntProduto = null

        }

        val adapter = listItem_categoria_beleza.adapter as ProdutoAdapter

        adapter.clear()
        adapter.addAll(produtosGlobalBeleza)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categoria_beleza)

        val adapter = ProdutoAdapter(this)
        listItem_categoria_beleza.adapter = adapter

        val arrayAdapter = ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, nomesProdutosBelezaGlobal)
        et_buscador_globalBeleza.setAdapter(arrayAdapter)

        btn_searchBeleza.setOnClickListener {
            listItem_categoria_beleza.setSelection(buscarItem())
        }

        btn_comprasBeleza.setOnClickListener {

            startActivity<CestaComprasActivity>()

        }

        btn_voltarBeleza.setOnClickListener {

            finishFromChild(this)

        }

        listItem_categoria_beleza.setOnItemClickListener { _, _, position, _ ->

            detalhesProduto = adapter.getItem(position)

            startActivity<DetalhesProdutosActivity>()

        }


    }

    private fun buscarItem(): Int{

        val item= et_buscador_globalBeleza.text.toString()
        et_buscador_globalBeleza.text.clear()
        val posicao: Int

        posicao = nomesProdutosBelezaGlobal.indexOf(item)

        return posicao

    }
}
