package livrokotlin.com.farmaciaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_minha_conta.*
import kotlinx.android.synthetic.main.activity_minha_conta.view.*
import livrokotlin.com.farmaciaapp.Conta.AlterarSenhaActivity
import livrokotlin.com.farmaciaapp.Conta.EnderecoUsuarioActivity
import org.jetbrains.anko.db.delete
import org.jetbrains.anko.startActivity
import java.nio.file.Files.delete

class MinhaContaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_minha_conta)

        alterar_senha.setOnClickListener {
            startActivity<AlterarSenhaActivity>()
        }

        seu_endereco.setOnClickListener {
            startActivity<EnderecoUsuarioActivity>()
        }

        sair.setOnClickListener {
            database.use {
                delete("DadosLogin")
            }
            startActivity<MainActivity>()
        }

    }
}
