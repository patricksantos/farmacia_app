package livrokotlin.com.farmaciaapp

import android.annotation.SuppressLint
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.text.Editable
import android.widget.TextView
import com.google.firebase.database.IgnoreExtraProperties
import kotlinx.android.synthetic.main.content_cesta_produtos.*
import kotlinx.android.synthetic.main.nav_header_home.*
import org.jetbrains.anko.db.ManagedSQLiteOpenHelper
import org.jetbrains.anko.db.TEXT
import org.jetbrains.anko.db.createTable

@IgnoreExtraProperties
data class User(
    var nome: String? = null,
    var email: String? = null,
    var rg: String? = null,
    var cpf: String? = null,
    var telefone: String? = null,
    var endereco: String? = null,
    var password: String? = null
)

var cpfGlobal:Editable? = null

var cpfDataBase: String? = null
var senhaDataBase: String? = null

data class DadosLogin(
    var cpf: String? = null,
    var senha: String? = null
)

var searchIntProduto: Int? = null

@SuppressLint("StaticFieldLeak")
var detalhesProduto: Produto? = null

var somaTotalProdutosGlobal: Double = 0.0

var adapterCestaGlobal:ProdutoCestaAdapter? = null

val produtosGlobal = mutableListOf<Produto>()

val produtosMinhaCesta = arrayListOf<Produto>()

val nomesProdutosGlobal = arrayListOf<String>()
val nomesProdutosSaudeGlobal = arrayListOf<String>()
val nomesProdutosInfantilGlobal = arrayListOf<String>()
val nomesProdutosBelezaGlobal = arrayListOf<String>()
val nomesProdutosHigieneGlobal = arrayListOf<String>()


val produtosGlobalSaude = mutableListOf<Produto>()
val produtosGlobalInfantil = mutableListOf<Produto>()
val produtosGlobalHigiene = mutableListOf<Produto>()
val produtosGlobalBeleza = mutableListOf<Produto>()


class SalvarDados(context: Context):ManagedSQLiteOpenHelper(ctx = context, name = "LoginApp.db", version = 1){
    override fun onCreate(db: SQLiteDatabase) {
        db.createTable(
            "DadosLogin",
            true,
            "cpf" to TEXT,
            "senha" to TEXT
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    companion object{

        private var instance: SalvarDados? = null
        @Synchronized
        fun getInstance(ctx: Context):SalvarDados {

            if(instance == null){
                instance = SalvarDados(ctx.applicationContext)
            }

            return instance!!
        }

    }

}

val Context.database: SalvarDados
    get() = SalvarDados.getInstance(applicationContext)


